<?php

namespace App\Services;

use App\Models\MaintenanceMode;
use App\Models\AuditLog;
use App\Models\User;

class MaintenanceService
{
    /**
     * Vérifier si l'application ou l'entreprise est actuellement en mode maintenance.
     */
    public function isMaintenanceActive(?int $companyId = null, ?int $branchId = null): ?MaintenanceMode
    {
        try {
            if (!\Illuminate\Support\Facades\Schema::hasTable('maintenance_modes')) {
                return null;
            }

            // 1. Vérifier la maintenance globale
            $global = MaintenanceMode::where('type', 'global')->where('enabled', true)->first();
            if ($global) {
                return $global;
            }

            // 2. Vérifier la maintenance ciblée par entreprise
            if ($companyId) {
                $companyMaint = MaintenanceMode::where('type', 'company')
                    ->where('company_id', $companyId)
                    ->where('enabled', true)
                    ->first();
                if ($companyMaint) {
                    return $companyMaint;
                }
            }

            return null;
        } catch (\Throwable $e) {
            return null;
        }
    }

    /**
     * Activer ou mettre à jour le mode maintenance.
     */
    public function setMaintenanceMode(array $data, ?User $user = null): MaintenanceMode
    {
        $type       = $data['type'] ?? 'global';
        $companyId  = !empty($data['company_id']) ? intval($data['company_id']) : null;
        $branchId   = !empty($data['branch_id']) ? intval($data['branch_id']) : null;
        $enabled    = filter_var($data['enabled'], FILTER_VALIDATE_BOOLEAN);
        $message    = $data['message'] ?? 'L\'application est temporairement en maintenance pour optimisation.';
        $startedAt  = $enabled ? now() : null;
        $endedAt    = !$enabled ? now() : null;

        // Si désactivation, réinitialiser TOUS les enregistrements correspondant au type
        if (!$enabled) {
            $resetQuery = MaintenanceMode::where('type', $type);
            if ($companyId) {
                $resetQuery->where('company_id', $companyId);
            } else {
                $resetQuery->whereNull('company_id');
            }
            $resetQuery->update([
                'enabled'  => false,
                'ended_at' => now(),
            ]);
        }

        $maintQuery = MaintenanceMode::where('type', $type);
        if ($companyId) {
            $maintQuery->where('company_id', $companyId);
        } else {
            $maintQuery->whereNull('company_id');
        }
        if ($branchId) {
            $maintQuery->where('branch_id', $branchId);
        } else {
            $maintQuery->whereNull('branch_id');
        }

        $maint = $maintQuery->first();
        if (!$maint) {
            $maint = new MaintenanceMode();
            $maint->type = $type;
            $maint->company_id = $companyId;
            $maint->branch_id = $branchId;
        }

        $maint->enabled          = $enabled;
        $maint->message          = $message;
        $maint->started_at       = $startedAt;
        $maint->estimated_end_at = !empty($data['estimated_end_at']) ? $data['estimated_end_at'] : null;
        $maint->ended_at         = $endedAt;
        if ($user) {
            $maint->created_by   = $user->id;
        }
        $maint->save();

        // Enregistrer l'événement dans le journal d'audit
        try {
            $userRoleStr = 'SuperAdmin';
            if ($user && $user->role) {
                $userRoleStr = is_object($user->role) ? ($user->role->name ?? $user->role->slug ?? 'SuperAdmin') : (string)$user->role;
            }

            AuditLog::create([
                'company_id'     => $companyId ?: 1,
                'user_id'        => $user?->id,
                'user_role'      => $userRoleStr,
                'auditable_type' => MaintenanceMode::class,
                'auditable_id'   => $maint->id,
                'action'         => $enabled ? 'MAINTENANCE_ENABLED' : 'MAINTENANCE_DISABLED',
                'module'         => 'SystemMaintenance',
                'description'    => ($enabled ? 'Activation' : 'Désactivation') . " de la maintenance [Type: {$type}]",
                'ip_address'     => request()->ip(),
                'device'         => request()->userAgent(),
                'result'         => 'success',
            ]);
        } catch (\Throwable $e) {
            \Illuminate\Support\Facades\Log::warning("Échec création AuditLog maintenance : " . $e->getMessage());
        }

        // 1. Nettoyage des anciennes notifications de maintenance et création d'une SEULE notification globale
        try {
            // Marquer comme lues toutes les anciennes notifications de maintenance pour éviter l'accumulation (e.g. 99+)
            \App\Models\Notification::whereNull('read_at')
                ->where(function ($q) {
                    $q->where('type', 'system')
                      ->where('title', 'like', '%Maintenance%');
                })
                ->update(['read_at' => now()]);

            $notifTitle = $enabled 
                ? '🛠️ Maintenance Système en cours' 
                : '🎉 Maintenance terminée — DLS POS est opérationnel';
            
            $notifMessage = $enabled 
                ? ($message ?: 'Une intervention de maintenance est actuellement en cours sur la plateforme DLS POS.')
                : 'L\'intervention de maintenance est terminée avec succès. Tous les services DLS POS (caisse, ventes, stocks) sont de nouveau pleinement opérationnels.';

            // Création d'une SEULE annonce globale unique (company_id IS NULL) accessible par tous les utilisateurs
            \App\Models\Notification::create([
                'company_id' => null,
                'branch_id'  => null,
                'user_id'    => null,
                'title'      => $notifTitle,
                'message'    => $notifMessage,
                'type'       => 'system',
                'priority'   => $enabled ? 'warning' : 'normal',
                'actor_id'   => null,
                'data'       => json_encode(['source' => 'maintenance_toggle', 'enabled' => $enabled])
            ]);
        } catch (\Throwable $e) {
            \Illuminate\Support\Facades\Log::warning("Échec création notification in-app de maintenance : " . $e->getMessage());
        }

        // 2. Transmettre les e-mails de notification en tâche de fond pour garantir une réponse HTTP instantanée (pas de 504 Timeout)
        register_shutdown_function(function () use ($enabled, $type, $companyId, $maint, $message) {
            try {
                $emailService = new \App\Services\EmailService();
                $status = $enabled ? 'started' : 'completed';
                $title = $enabled ? 'Intervention de Maintenance Système SaaS' : '🎉 Fin de l\'Intervention de Maintenance DLS POS';
                $endsAtStr = $maint->estimated_end_at ? \Carbon\Carbon::parse($maint->estimated_end_at)->format('d/m/Y H:i') : null;
                $startsAtStr = $maint->started_at ? $maint->started_at->format('d/m/Y H:i') : null;
                $mailBody = $enabled 
                    ? ($message ?: 'Une intervention de maintenance est actuellement en cours sur la plateforme DLS POS.')
                    : 'Nous vous informons que la maintenance système est officiellement terminée. La plateforme DLS POS est de nouveau disponible et pleinement fonctionnelle pour toutes vos opérations.';

                $companies = ($type === 'global') ? \App\Models\Company::all() : ($companyId ? \App\Models\Company::where('id', $companyId)->get() : collect());

                foreach ($companies as $comp) {
                    $recipients = [];
                    if (!empty($comp->email)) {
                        $recipients[] = trim($comp->email);
                    }

                    $activeUsers = \App\Models\User::withoutGlobalScopes()
                        ->where('company_id', $comp->id)
                        ->where('status', 'active')
                        ->get();

                    foreach ($activeUsers as $uItem) {
                        if (!empty($uItem->email)) {
                            $recipients[] = trim($uItem->email);
                        }
                    }

                    foreach (array_unique(array_filter($recipients)) as $recipientEmail) {
                        try {
                            $emailService->sendMaintenanceNotificationEmail(
                                recipient: $recipientEmail,
                                title: $title,
                                messageBody: $mailBody,
                                status: $status,
                                startsAt: $startsAtStr,
                                endsAt: $endsAtStr,
                                companyId: $comp->id
                            );
                            \Illuminate\Support\Facades\Log::info("Mail de maintenance expédié à : {$recipientEmail}");
                        } catch (\Throwable $ex) {
                            \Illuminate\Support\Facades\Log::warning("Échec envoi mail maintenance à {$recipientEmail} : " . $ex->getMessage());
                        }
                    }
                }
            } catch (\Throwable $err) {
                \Illuminate\Support\Facades\Log::warning("Erreur globale envoi mails maintenance : " . $err->getMessage());
            }
        });

        return $maint;
    }
}
