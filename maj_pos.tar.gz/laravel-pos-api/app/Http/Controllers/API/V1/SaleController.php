<?php

namespace App\Http\Controllers\API\V1;

use App\Http\Controllers\Controller;
use App\Models\Sale;
use App\Models\SaleDetail;
use App\Models\CashSession;
use App\Models\CashSessionTransaction;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Events\Sale\SaleCreated;
use App\Events\Stock\StockLow;
use App\Services\AuthorizationService;

class SaleController extends Controller
{
    /**
     * Liste des ventes de la compagnie (filtrée par tenant) avec filtres.
     */
    public function index(Request $request)
    {
        $query = Sale::with(['details.product', 'user', 'branch', 'customer']);

        $branchId = $request->input('branch_id');
        if (empty($branchId) || $branchId === 'undefined') {
            $branchId = app(\App\Services\TenantManager::class)->getBranchId();
        }

        if ($branchId && $branchId !== 'all') {
            $query->where('branch_id', $branchId);
        }
        if ($request->filled('payment_method')) {
            $query->where('payment_method', $request->payment_method);
        }

        // Filtre par statut de paiement
        if ($request->filled('payment_status')) {
            $query->where('payment_status', $request->payment_status);
        }

        // Filtre par date (du … au …)
        if ($request->filled('date_from')) {
            $query->whereDate('created_at', '>=', $request->date_from);
        }
        if ($request->filled('date_to')) {
            $query->whereDate('created_at', '<=', $request->date_to);
        }

        // Recherche par nom/téléphone client ou numéro de vente
        if ($request->filled('search')) {
            $s = $request->search;
            $query->where(function ($q) use ($s) {
                $q->where('sale_number', 'like', "%{$s}%")
                  ->orWhere('client_name', 'like', "%{$s}%")
                  ->orWhere('client_phone', 'like', "%{$s}%");
            });
        }

        $sales = $query->orderByDesc('created_at')->paginate(20);

        return response()->json($sales);
    }

    /**
     * Enregistrer une nouvelle vente depuis le terminal POS.
     *
     * - Calcule le sous-total, la TVA (18 %), la remise et le total.
     * - Décrémente le stock de chaque article vendu dans la boutique active.
     * - Enregistre une transaction de type "sale" dans la session de caisse ouverte.
     * - Génère un numéro de vente séquentiel unique par compagnie.
     */
    public function store(Request $request)
    {
        $user = $request->user();

        // Récupérer la session de caisse ou trouver la session ouverte de l'utilisateur
        $sessionId = $request->cash_session_id;
        $session = null;

        if ($sessionId && $sessionId > 0) {
            $session = CashSession::where('id', $sessionId)->where('status', 'open')->first();
        }

        if (!$session) {
            $session = CashSession::where('user_id', $user->id)
                ->where('status', 'open')
                ->latest()
                ->first();
        }

        if (!$session) {
            // Créer une session de caisse automatique pour autoriser l'encaissement
            $branchId = app(\App\Services\TenantManager::class)->getBranchId() ?? $user->branch_id ?? 1;
            $session = CashSession::create([
                'company_id' => $user->company_id,
                'branch_id' => $branchId,
                'user_id' => $user->id,
                'opening_amount' => 0,
                'opening_balance' => 0,
                'opened_at' => now(),
                'status' => 'open'
            ]);
        }

        $request->merge(['cash_session_id' => $session->id]);

        $request->validate([
            'idempotency_key' => 'nullable|string|max:64',
            'cash_session_id' => 'required|exists:cash_sessions,id',
            'payment_method'  => 'required|in:cash,card,credit',
            'customer_id'     => 'nullable|exists:customers,id',
            'items'           => 'required|array|min:1',
            'items.*.product_id'    => 'required|exists:products,id',
            'items.*.quantity'      => 'required|numeric|min:0.01',
            'items.*.selling_price' => 'required|numeric|gt:0',
            'items.*.discount'      => 'nullable|numeric|min:0',
            'global_discount'       => 'nullable|numeric|min:0',
            'amount_received'       => 'nullable|numeric|min:0',
            'client_name'           => 'nullable|string|max:255',
            'client_phone'          => 'nullable|string|max:50',
        ]);

        $customer = null;
        if ($request->customer_id) {
            $customer = \App\Models\Customer::find($request->customer_id);
        }

        // Vérification backend stricte de la permission de remise (sales.discount)
        $hasDiscount = floatval($request->global_discount ?? 0) > 0;
        if (!$hasDiscount && is_array($request->items)) {
            foreach ($request->items as $item) {
                if (floatval($item['discount'] ?? 0) > 0) {
                    $hasDiscount = true;
                    break;
                }
            }
        }

        $authService = app(AuthorizationService::class);
        if ($hasDiscount && !$authService->hasPermission($user, 'sales.discount')) {
            return response()->json([
                'error' => "Accès refusé. La permission 'sales.discount' est requise pour appliquer une remise sur la vente."
            ], 403);
        }

        // Récupérer les paramètres de TVA de l'entreprise
        $company = \App\Models\Company::find($user->company_id);
        $taxSettings = $company->tax_settings ?? ['tax_rate' => 18, 'enable_tax' => true];
        $enableTax = isset($taxSettings['enable_tax']) ? (bool)$taxSettings['enable_tax'] : true;
        $taxRatePercent = $enableTax ? floatval($taxSettings['tax_rate'] ?? 18) : 0;
        $taxFactor = $taxRatePercent / 100;

        // Calculer les totaux de simulation pour vérifier la limite de crédit
        $subtotalSim = 0;
        $itemDiscountsSim = 0;
        foreach ($request->items as $item) {
            $subtotalSim += floatval($item['quantity']) * floatval($item['selling_price']);
            $itemDiscountsSim += floatval($item['discount'] ?? 0);
        }
        $totalDiscountSim = $itemDiscountsSim + floatval($request->global_discount ?? 0);
        $netSubtotalSim   = max(0, $subtotalSim - $totalDiscountSim);
        $taxSim           = round($netSubtotalSim * $taxFactor, 2);
        $totalSim         = round($netSubtotalSim + $taxSim, 2);

        if ($request->payment_method === 'credit') {
            if (!$customer) {
                return response()->json(['error' => 'Un client enregistré est requis pour une vente à crédit.'], 422);
            }
            $newDebt = $customer->debt_balance + $totalSim;
            if ($customer->credit_limit > 0 && $newDebt > $customer->credit_limit) {
                return response()->json([
                    'error' => "Le plafond de crédit du client est dépassé (Dette actuelle : {$customer->debt_balance} XOF, Nouveau total : {$newDebt} XOF, Plafond autorisé : {$customer->credit_limit} XOF)."
                ], 422);
            }
        }

        if ($request->idempotency_key) {
            $existingSale = Sale::where('company_id', $user->company_id)
                ->where('idempotency_key', $request->idempotency_key)
                ->first();
            if ($existingSale) {
                $existingSale->load('details.product', 'user', 'branch');
                return response()->json([
                    'message' => 'Vente déjà enregistrée (idempotent).',
                    'sale' => $existingSale,
                ], 200);
            }
        }

        try {
            return DB::transaction(function () use ($request, $user, $session, $customer, $taxFactor) {
                // Calculer les totaux réels pour la transaction
                $subtotal = 0;
                $itemDiscounts = 0;
                $globalDiscount = floatval($request->global_discount ?? 0);
                $details = [];

                foreach ($request->items as $item) {
                    $qty   = floatval($item['quantity']);
                    $price = floatval($item['selling_price']);
                    $disc  = floatval($item['discount'] ?? 0);

                    $lineSubtotal = $qty * $price;
                    $subtotal += $lineSubtotal;
                    $itemDiscounts += $disc;

                    // TVA par ligne selon les paramètres de l'entreprise
                    $lineTax   = ($lineSubtotal - $disc) * $taxFactor;
                    $lineTotal = ($lineSubtotal - $disc) + $lineTax;

                    $details[] = [
                        'product_id'    => $item['product_id'],
                        'quantity'      => $qty,
                        'selling_price' => $price,
                        'discount'      => $disc,
                        'tax'           => round($lineTax, 2),
                        'total'         => round($lineTotal, 2),
                    ];
                }

                $totalDiscount = $itemDiscounts + $globalDiscount;
                $netSubtotal   = max(0, $subtotal - $totalDiscount);
                $tax           = round($netSubtotal * $taxFactor, 2);
                $total         = round($netSubtotal + $tax, 2);

                $amountReceived = floatval($request->amount_received ?? $total);
                $change = max(0, round($amountReceived - $total, 2));

                // Numéro de vente séquentiel atomique (Résistant à la concurrence)
                $activeBranchId = app(\App\Services\TenantManager::class)->getBranchId() ?: ($user->branch_id ?: $session->branch_id);
                $saleNumber = \App\Services\SaleNumberGenerator::generate($user->company_id ?: $session->company_id, $activeBranchId);

                $paymentStatus = 'paid';
                if ($request->payment_method === 'credit') {
                    $paymentStatus = 'unpaid';
                    $customer->update([
                        'debt_balance' => $customer->debt_balance + $total
                    ]);
                }

                // Gérer les points de fidélité (1 point par 1000 XOF d'achat)
                if ($customer) {
                    $points = floor($total / 1000);
                    if ($points > 0) {
                        $customer->increment('loyalty_points', $points);
                    }
                }

                // Créer la vente
                $sale = Sale::create([
                    'idempotency_key' => $request->idempotency_key,
                    'company_id'      => $user->company_id ?: $session->company_id,
                    'branch_id'       => $activeBranchId,
                    'user_id'         => $user->id,
                    'cash_session_id' => $session->id,
                    'customer_id'     => $customer ? $customer->id : null,
                    'sale_number'     => $saleNumber,
                    'client_name'     => $customer ? $customer->name : ($request->client_name ?? 'Client Comptant'),
                    'client_phone'    => $customer ? $customer->phone : $request->client_phone,
                    'subtotal'        => round($subtotal, 2),
                    'discount'        => round($totalDiscount, 2),
                    'tax'             => $tax,
                    'total'           => $total,
                    'payment_method'  => $request->payment_method,
                    'payment_status'  => $paymentStatus,
                    'amount_received' => $request->payment_method === 'credit' ? 0 : $amountReceived,
                    'amount_change'   => $request->payment_method === 'credit' ? 0 : $change,
                ]);

                // Créer les détails et décrémenter le stock avec verrouillage pessimiste lockForUpdate()
                foreach ($details as $d) {
                    $sale->details()->create($d);

                    // Auto-initialiser la ligne de stock si elle n'existe pas encore
                    $branchProduct = \App\Models\BranchProduct::firstOrCreate([
                        'branch_id'  => $activeBranchId,
                        'product_id' => $d['product_id'],
                    ], [
                        'quantity'  => 0.00,
                        'is_active' => true,
                    ]);

                    // Verrouiller la ligne de stock pour la transaction
                    $branchProduct = \App\Models\BranchProduct::where('id', $branchProduct->id)
                        ->lockForUpdate()
                        ->first();

                    $availableQty = $branchProduct ? floatval($branchProduct->quantity) : 0;
                    if ($availableQty < $d['quantity']) {
                        $product = \App\Models\Product::find($d['product_id']);
                        $pName = $product ? $product->name : "ID {$d['product_id']}";
                        throw new \Exception("Stock insuffisant pour \"{$pName}\" dans cette boutique (Disponible: {$availableQty}, Demandé: {$d['quantity']}).");
                    }

                    $branchProduct->decrement('quantity', $d['quantity']);

                    // Mouvement de stock de type "sale"
                    DB::table('stock_movements')->insert([
                        'company_id'   => $user->company_id,
                        'branch_id'    => $activeBranchId,
                        'product_id'   => $d['product_id'],
                        'type'         => 'sale',
                        'quantity'     => -$d['quantity'],
                        'reference_id' => $sale->id,
                        'description'  => "Vente {$saleNumber} par {$user->name}",
                        'created_at'   => now(),
                        'updated_at'   => now(),
                    ]);
                }

                // Enregistrer la transaction dans la session de caisse
                CashSessionTransaction::create([
                    'cash_session_id' => $session->id,
                    'type'            => 'deposit',
                    'amount'          => $total,
                    'description'     => "Vente {$saleNumber} ({$request->payment_method})",
                ]);

                $sale->load('details.product', 'user', 'branch');

                // ── Événement SaleCreated → NotifySaleEvents listener (ciblé par rôle) ──
                try {
                    event(new SaleCreated($sale, $user));
                } catch (\Throwable $e) {
                    \Illuminate\Support\Facades\Log::error('SaleCreated event error: ' . $e->getMessage());
                }

                // ── Détection automatique de stock faible après la vente ──
                try {
                    foreach ($details as $d) {
                        $bp = \App\Models\BranchProduct::where('branch_id', $activeBranchId)
                            ->where('product_id', $d['product_id'])
                            ->first();
                        $product = \App\Models\Product::find($d['product_id']);
                        if ($bp && $product && $product->alert_quantity !== null) {
                            if (floatval($bp->quantity) <= floatval($product->alert_quantity)) {
                                event(new StockLow(
                                    $user->company_id,
                                    $activeBranchId,
                                    $product->id,
                                    $product->name,
                                    floatval($bp->quantity),
                                    floatval($product->alert_quantity)
                                ));
                            }
                        }
                    }
                } catch (\Throwable $e) {
                    \Illuminate\Support\Facades\Log::error('StockLow event error: ' . $e->getMessage());
                }

                return response()->json([
                    'message' => 'Vente enregistrée avec succès.',
                    'sale'    => $sale,
                ], 201);
            });
        } catch (\Throwable $e) {
            \Illuminate\Support\Facades\Log::error('SaleController store error: ' . $e->getMessage(), ['trace' => $e->getTraceAsString()]);
            $isDb = \App\Services\ErrorSanitizer::isDatabaseError($e);
            $safeMsg = \App\Services\ErrorSanitizer::sanitize($e, 'Une erreur est survenue lors de l\'enregistrement de la vente.');
            return response()->json([
                'error' => $safeMsg
            ], $isDb ? 500 : 400);
        }
    }

    /**
     * Afficher le détail d'une vente.
     */
    public function show($id)
    {
        $sale = Sale::with(['details.product', 'user', 'branch', 'customer'])->findOrFail($id);
        return response()->json($sale);
    }

    /**
     * Annuler une vente avec restitution des stocks (sales.cancel).
     */
    public function cancel(Request $request, $id)
    {
        $user = $request->user();
        $authService = app(AuthorizationService::class);
        if (!$authService->hasPermission($user, 'sales.cancel')) {
            return response()->json([
                'error' => "Accès refusé. La permission 'sales.cancel' est obligatoire pour annuler une vente."
            ], 403);
        }

        $sale = Sale::with('details')->findOrFail($id);
        if ($sale->payment_status === 'cancelled') {
            return response()->json(['error' => 'Cette vente est déjà annulée.'], 422);
        }

        return DB::transaction(function () use ($sale, $user) {
            $sale->payment_status = 'cancelled';
            $sale->save();

            // Re-créditer les stocks
            foreach ($sale->details as $detail) {
                $bp = \App\Models\BranchProduct::where('branch_id', $sale->branch_id)
                    ->where('product_id', $detail->product_id)
                    ->first();
                if ($bp) {
                    $bp->quantity = floatval($bp->quantity) + floatval($detail->quantity);
                    $bp->save();
                }

                \App\Models\StockMovement::create([
                    'company_id'   => $sale->company_id,
                    'branch_id'    => $sale->branch_id,
                    'product_id'   => $detail->product_id,
                    'type'         => 'cancel_sale',
                    'quantity'     => $detail->quantity,
                    'reference_id' => $sale->id,
                    'description'  => "Annulation vente #{$sale->sale_number} par {$user->name}",
                    'created_at'   => now(),
                    'updated_at'   => now(),
                ]);
            }

            return response()->json(['message' => "La vente #{$sale->sale_number} a été annulée avec succès.", 'sale' => $sale]);
        });
    }

    /**
     * Rembourser une vente (sales.refund).
     */
    public function refund(Request $request, $id)
    {
        $user = $request->user();
        $authService = app(AuthorizationService::class);
        if (!$authService->hasPermission($user, 'sales.refund')) {
            return response()->json([
                'error' => "Accès refusé. La permission 'sales.refund' est obligatoire pour effectuer un remboursement."
            ], 403);
        }

        $sale = Sale::findOrFail($id);
        if ($sale->payment_status === 'refunded') {
            return response()->json(['error' => 'Cette vente a déjà été remboursée.'], 422);
        }

        $sale->payment_status = 'refunded';
        $sale->save();

        return response()->json(['message' => "La vente #{$sale->sale_number} a été marquée comme remboursée.", 'sale' => $sale]);
    }
}
